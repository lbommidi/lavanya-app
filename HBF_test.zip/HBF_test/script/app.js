
 var app= angular.module("myApp", []);
		
		
app.controller('myController1',function($scope){
$scope.uname="";
$scope.email="";
$scope.phNo="";
$scope.roomPrice = [
                {
                    RoomType: "Single", Fare: 1200
                },
                {
                    RoomType: "Single Delux", Fare: 1800
                },
                {
                    RoomType: "Double", Fare: 2200
                },
                {
                    RoomType: "Double Delux", Fare: 2800
                },
                {
                    RoomType: "Family Room", Fare: 3500
                }
            ];
	
			$scope.cust = [
      {
        uname: "Ramesh",
        email: "ramesh@acb.com",
        phNo: "9963258741",
		roomper:"Single",
		daycost:"2",
		cost:"2400"
      },
		{
        uname: "Vilas",
        email: "vilas@qwe.com",
        phNo: "9963021458",
		roomper:"Double",
		daycost:"1",
		cost:"2200"
      },
		{
        uname: "Dinesh",
        email: "dinesh@gmail.com",
        phNo: "9123654789",
		roomper:"Single",
		daycost:"2",
		cost:"2400"
      },
		{
        uname: "Prathu",
        email: "prathu@mail.com",
        phNo: "8845752390",
		roomper:"Family Room",
		daycost:"2",
		cost:"7000"
      },
		{
        uname: "Ashok",
        email: "ashok998@mail.com",
        phNo: "9963201478",
		roomper:"Single Delux",
		daycost:"1",
		cost:"1800"
      }];
	
 $scope.addCust = function(){
        $scope.cust.push({ uname:$scope.uname, email:$scope.email, phNo:$scope.phNo, roomper:$scope.roomper.RoomType, daycost:$scope.daycost, cost:$scope.roomper.Fare*$scope.daycost });
    };
    
    $scope.totalCust    =   function(){
        return $scope.cust.length;    
    };

 	
});
 app.controller("myController", function ($scope) {

 $scope.showMe = false;
    $scope.myFunc = function() {
        $scope.showMe = !$scope.showMe;
    }
            $scope.hotel = [
                {
                    RoomType: "Single", NoRooms: 10, Fare: 1200
                },
                {
                    RoomType: "Single Delux", NoRooms: 15, Fare: 1800
                },
                {
                    RoomType: "Double", NoRooms: 20, Fare: 2200
                },
                {
                    RoomType: "Double Delux", NoRooms:25, Fare: 2800
                },
                {
                    RoomType: "Family Room", NoRooms:05, Fare: 3500
                }
            ];

            $scope.rowCount = 3;
        });

		

app.controller('myCtrl', function($scope, $location) 
{
    $scope.myUrl = $location.absUrl();
});

/* Not working */
app.controller('infoCtrl', function($scope, $http) 
{
    $http.get("welcome.htm").then(function (response) 
	{
        $scope.myWelcome = response.data;
    });
});

app.controller('timeTxtCtrl', function($scope, $timeout) {
  $scope.myHeader = "Welcome To Hotel Vilas!!";
  $timeout(function () {
      $scope.myHeader = "Book your rooms....!";
  }, 3000);
});



app.controller('clockCtrl', function($scope, $interval) {
  $scope.theTime = new Date().toLocaleTimeString();
  $interval(function () {
      $scope.theTime = new Date().toLocaleTimeString();
  }, 1000);
});

app.controller('phonePattrn', function($scope) {
      $scope.phoneNumbr = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;
    });

