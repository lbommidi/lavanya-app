var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider

  .when('/', {
    templateUrl : 'home.html',
    controller  : 'HomeController'
  })

  .when('/tarrif', {
    templateUrl : 'tarrif.html',
    controller  : 'TarrifController'
  })

  .when('/about', {
    templateUrl : 'about.html',
    controller  : 'AboutController'
  })

  .otherwise({redirectTo: '/'});
})

app.controller('HomeController', function($scope) {
  $scope.message = 'Hello from HomeController';
});

app.controller('TarrifController', function($scope) {
  $scope.message = 'Hello from TarrifController';
});

app.controller('AboutController', function($scope) {
  $scope.message = 'Hello from AboutController';
});
