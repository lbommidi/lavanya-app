var app1 = angular.module('loginApp',[]);

app1.run(function($rootScope,$http){
	
		$http.get("user.json").then(function (response) {
		$rootScope.myData = response.data.user;
		
		});
		});
		app1.controller('loginCtrl',function($location,$scope){
		
		$scope.submit=function()
		{
		var userNm=$scope.uname;
		var passWrd=$scope.pass;
		
		
		if(userNm== $scope.myData[0].uSname && passWrd==$scope.myData[0].passWd)
		{
		// $location.path('/myApp.html');
		window.location.href = 'myApp.html';
		}
		else{
		$scope.message="Wrong Credentials";
		
		}
		}
		});
	
	
	
	app1.controller('myCtrl', function($scope, $location) 
{
    $scope.myUrl = $location.absUrl();
});